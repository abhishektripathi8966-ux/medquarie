# Build roadmap

1. Authentication + profile/role creation
2. Google OAuth + email/password verification
3. Organization and professional verification
4. Medication case creation and assignment
5. Deterministic safety engine
6. AI structured analysis + model/prompt versioning
7. Pharmacist review and teach-back
8. Doctor clarification workflow
9. Admin controls
10. Research annotation and metrics
11. OCR and authoritative drug-label source connectors
12. Security, audit, accessibility and deployment tests
13. Governance/validation before any clinical use
