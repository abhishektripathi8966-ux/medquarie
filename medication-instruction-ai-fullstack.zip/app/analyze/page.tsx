import AnalyzeForm from '@/components/AnalyzeForm';
export default function AnalyzePage(){return <><h1>Medication Instruction Analyzer</h1><p className="muted">Enter an instruction to demonstrate the pharmacist-support screening workflow.</p><AnalyzeForm/></>}
