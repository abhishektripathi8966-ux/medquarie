# Medication Instruction AI — Working Full-Stack Prototype

This repository is the working prototype foundation for a pharmacist-support research application that screens medication instructions for potential patient confusion.

## Important
- The included 10,000 records are **synthetic demo cases**, not real patient records.
- The prototype is not clinically validated and must not be presented as clinical decision support without appropriate validation/governance.
- AI cannot independently change clinically meaningful medication information.

## Features in this starter
- Next.js + TypeScript application
- Live instruction analyzer endpoint
- Deterministic safety-rule layer before AI
- OpenAI Responses API integration when `OPENAI_API_KEY` is configured
- Safe demo fallback when no API key is configured
- 10,000 synthetic case CSV included
- Case explorer
- Presentation mode
- Supabase/Postgres migration with initial roles/case/analysis/review/audit tables
- RLS starting policies

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`.

Without an OpenAI key, `/analyze` uses clearly-labelled deterministic demo analysis. With a valid server-side key, it calls the OpenAI Responses API.

## Supabase
1. Create a Supabase project.
2. Run `supabase/migrations/001_initial.sql` in the SQL editor.
3. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
4. Keep `SUPABASE_SERVICE_ROLE_KEY` server-side only.

## Production hardening still required
- Complete Supabase Auth UI and Google OAuth configuration
- Full role/organization authorization policies
- Professional verification workflow
- Secure patient/professional assignment rules
- Complete pharmacist/doctor/admin dashboards
- Audit event coverage
- Rate limiting and abuse protection
- OCR integration
- Public-label source integration
- Research annotation/evaluation screens
- Automated security/accessibility tests
- Clinical validation, ethics/privacy review and jurisdiction-specific governance before real patient use
